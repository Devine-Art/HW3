﻿namespace Simula_s_Test
{
    internal class Program
    {
        static void Main(string[] args)
        {


            while (1 == 1)
            {
                //ask user for input
                Console.WriteLine("What do you want to do?");
                string action = Console.ReadLine();

                switch(action)
                {
                    case action == "close":
                }

            }
            enum State {Open, Closed, Locked}
        }
    }
}